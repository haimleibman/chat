import { atom } from "recoil"

export const userName = atom({
    key: 'nameStatte',
    default: ''
})