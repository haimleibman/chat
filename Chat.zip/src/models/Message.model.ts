export default interface Message {
    name: string,
    text: string
}